# 問題 1：資料視覺化實測

從本資料夾執行：

```bash
python3 src/test_question1.py
```

使用 Python、pandas、Matplotlib、Seaborn、Pillow；中文字型為 Noto Sans CJK TC。
原始 CSV 在 data/raw/，圖片在 outputs/figures/，測試報告在 outputs/reports/。
重跑時輸出以版本號另存，不覆寫既有成果。
